//>>built
define("dgrid/extensions/nls/de/columnHider",{popupLabel:"Spalten ein- oder ausblenden"});