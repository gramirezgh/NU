//>>built
define("dgrid/extensions/nls/et/columnHider",{popupLabel:"Kuva v\u00f5i peida veerud"});