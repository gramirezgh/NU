//>>built
define(["dojo/_base/declare","./Dialog","./_ConfirmDialogMixin"],function(a,b,c){return a("dijit.ConfirmDialog",[b,c],{})});