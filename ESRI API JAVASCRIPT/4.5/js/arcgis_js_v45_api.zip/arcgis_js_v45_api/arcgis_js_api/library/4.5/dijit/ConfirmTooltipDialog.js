//>>built
define(["dojo/_base/declare","./TooltipDialog","./_ConfirmDialogMixin"],function(a,b,c){return a("dijit.ConfirmTooltipDialog",[b,c],{})});