//>>built
define(["./query"],function(a){return a.NodeList});