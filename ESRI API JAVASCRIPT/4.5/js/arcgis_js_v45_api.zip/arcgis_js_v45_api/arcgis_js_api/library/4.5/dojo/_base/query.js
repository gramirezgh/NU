//>>built
define(["../query","./NodeList"],function(a){return a});