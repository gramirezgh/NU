//>>built
define(["../_base/declare","./Source"],function(a,b){return a("dojo.dnd.AutoSource",b,{constructor:function(){this.autoSync=!0}})});