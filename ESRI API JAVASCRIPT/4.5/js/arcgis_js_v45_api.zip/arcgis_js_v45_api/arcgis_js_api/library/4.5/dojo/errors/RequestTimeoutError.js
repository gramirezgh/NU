//>>built
define(["./create","./RequestError"],function(a,b){return a("RequestTimeoutError",null,b,{dojoType:"timeout"})});