//>>built
define(["./_base/loader"],function(a){return{dynamic:0,normalize:function(a){return a},load:a.require}});