//>>built
define(["./drawing/_base"],function(){});