//>>built
define(["./fx/_base"],function(a){return a});