//>>built
define(["./mvc/_base"],function(a){return a});