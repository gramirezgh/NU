//>>built
define("dojo/_base/kernel dojo/_base/lang ./xml/DomParser ./sketch/UndoStack ./sketch/Figure ./sketch/Toolbar".split(" "),function(a){a.getObject("sketch",!0,dojox);return dojox.sketch});