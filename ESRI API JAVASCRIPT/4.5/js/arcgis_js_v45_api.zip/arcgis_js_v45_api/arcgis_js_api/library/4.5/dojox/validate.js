//>>built
define(["./validate/_base"],function(a){return a});